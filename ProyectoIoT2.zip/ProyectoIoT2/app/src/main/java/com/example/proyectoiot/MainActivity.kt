package com.example.proyectoiot

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var etUsuario: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnIngresar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUsuario = findViewById(R.id.etUsuario)
        etPassword = findViewById(R.id.etPassword)
        btnIngresar = findViewById(R.id.btnIngresar)

        btnIngresar.setOnClickListener {
            val usuario = etUsuario.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (usuario.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Conectando con Raspberry Pi...", Toast.LENGTH_SHORT).show()
                enviarDatosRaspberry(usuario, password)
            } else {
                Toast.makeText(this, "Error: Debe ingresar usuario y contraseña", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun enviarDatosRaspberry(usuario: String, pass: String) {
        val ipRaspberry = "http://192.168.1.6/insertar.php"

        Thread {
            try {
                val url = URL("$ipRaspberry?usuario=$usuario&clave=$pass")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val responseCode = connection.responseCode
                runOnUiThread {
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        Toast.makeText(this, "¡Datos enviados con éxito a Raspberry y AWS!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Error en el servidor PHP: $responseCode", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Fallo de conexión: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}